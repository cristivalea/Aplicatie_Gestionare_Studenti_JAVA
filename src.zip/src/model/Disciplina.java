package model;

import teste.Main2;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Disciplina {
    private short codDisciplina;
    private String numeDisciplina;
    private double coefExamne;
    private double coefParcurs;
    private short nrCredite;
    private static ArrayList<Short> coduriExistente = new ArrayList<Short>();

    public Disciplina(short codD, String numeD, double coefE, double coefP, short nrC) {
        this.codDisciplina = codD;
        this.numeDisciplina = numeD;
        this.coefExamne = coefE;
        this.coefParcurs = coefP;
        this.nrCredite = nrC;
    }

    public Disciplina(String linie) {
        Scanner scanner = new Scanner(linie);
        scanner.useDelimiter(";");
        short codD = scanner.nextShort();
        this.codDisciplina = codD;
        this.numeDisciplina = scanner.next();
        double coefEx = scanner.nextDouble();
        this.coefExamne = coefEx;
        double coefP = scanner.nextDouble();
        this.coefParcurs = coefP;
        this.nrCredite = scanner.nextShort();
        scanner.close();
        Main2.logger.info("S-a incarcat disciplina" + this.codDisciplina + ";" + this.numeDisciplina + ";" + this.coefExamne + ";" + this.coefExamne + ";" + this.coefParcurs + ";" + this.nrCredite);
    }

    public Disciplina(){
        Random random = new Random();
        short auxCod = (short)(100 + random.nextInt(9899));
        if(coduriExistente.size() == 0){
            this.codDisciplina = auxCod;
            addCoduri(auxCod);
        }
        else{
            while (verificareExistenta(auxCod)){
                auxCod = (short)(100 + random.nextInt(9899));
            }
            this.codDisciplina = auxCod;
            addCoduri(auxCod);
        }
        this.numeDisciplina = " ";
        this.coefExamne = 0.5;
        this.coefParcurs = 0.5;
        this.nrCredite = 5;
    }

    public static void addCoduri(short nouCod){

        coduriExistente.add(nouCod);
    }

    private static boolean verificareExistenta(short codNou){
        for(int i = 0; i < coduriExistente.size(); i++){
            if(coduriExistente.get(i) == codNou){
                return true;
            }
        }
        return false;
    }

    public short getCodDisciplina(){

        return this.codDisciplina;
    }

    public String getNumeDisciplina(){
        return this.numeDisciplina;
    }

    public double getCoefExamne(){
        return this.coefExamne;
    }

    public double getCoefParcurs() {
        return coefParcurs;
    }

    public short getNrCredite() {
        return nrCredite;
    }


    public void setNumeDisciplina(String numeDisciplina) {
        this.numeDisciplina = numeDisciplina;
    }

    public void setCoefExamne(double coefExamne) {
        this.coefExamne = coefExamne;
    }

    public void setCoefParcurs(double coefParcurs) {
        this.coefParcurs = coefParcurs;
    }

    public boolean equals(Object obj){
        if(obj == null){
            return false;
        }
        if(obj instanceof Disciplina){
            Disciplina d = (Disciplina) obj;
            if(d.codDisciplina == this.codDisciplina){
                return true;
            }
        }
        return false;
    }

    public String toString(){
        return this.codDisciplina + " " + this.numeDisciplina + " " + this.coefExamne + " " + this.coefParcurs + " " + this.nrCredite + "\n";
    }
}

